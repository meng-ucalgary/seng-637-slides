#!/usr/bin/python
import time
import datetime
import random
import csv
import os
import urllib
import urllib.request
import pymysql
try:    
    import thread 
except ImportError:
    import _thread as thread
total_codes=145
delay = 10

validCodesFile = "codes.txt"
localErrors = "storedErrCodes.txt"
validCodes= []
matchedCodes = []

vehicleID = 1234

checkConnection = 0
goodConnection = 0

def checkInternetConn():
	global checkConnection
	global goodConnection

	#if connection has not been checked, check it
	if checkConnection == 0:
		try:
			checkConnection = 1
			urllib.request.urlopen("http://www.google.com", timeout=1)
		except urllib.request.URLError:
			print("No internet connection. Will store all codes locally")
			goodConnection = 0

		else:
			print("Connected to internet. Will attempt store all codes in database")
			goodConnection = 1
			


# Send error data to the database
def executeSQL():
	global matchedCodes
	global vehicleID

	#get datetime to identify when the error was found
	dateTime=datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

	#Open database connection
	try:
		db = pymysql.connect("localhost","root","521","521Project") #change to LAN address when on PI
	except:
		print("Could not connect to database. Storing locally...")
		storeErrLocal()
		return;

	cursor = db.cursor()
	
	#for each valid error code, insert a record into the DB
	for match in matchedCodes:
		
		sql = "INSERT INTO errorCodes(errorID, dateTime, vehicleID) VALUES ('{}', '{}', '{}')".format(match,dateTime,vehicleID)
		print(sql)
		try:
			cursor.execute(sql)
			db.commit()
		except:
			db.rollback()
			print("Error inserting error codes into DB. Storing locally... ")
			time.sleep(1)
			storeErrLocal()
	db.close()


# Stores error codes locally if no connection to internet, or database connection refused
def storeErrLocal():
	global localErrors
	with open( localErrors, 'a') as f:
		for matchedCode in matchedCodes:
			f.write("%s\n" % matchedCode)


	

# Check for connection and store locally or send error codes to DB
def sendErrCodes():
	global checkConnection
	global matchedCodes
	global localErrors
	global goodConnection

	checkInternetConn()	
	
	#if internet connection exists, attempt to connect to DB and store error codes in table
	if goodConnection == 1:	
		executeSQL()
	#if no internet connection exists, store in local file
	else:
		storeErrLocal()

#if any valid codes exist in 
def checkLocal():
	global localErrors
	global matchedCodes
	if goodConnection == 1:
		with open(localErrors, newline='\n') as f:
				matchedCodes = f.read().splitlines()
		if matchedCodes:
			sendErrCodes()
		matchedCodes.clear()

# Function to scan for relative codes
def scanCSV(fileName):
	global validCodes
	global matchedCodes
	print(fileName)
	time.sleep(2)

#Read error data from CSV file into 'readCodes' variable
	with open( fileName, newline='') as f:
		reader = csv.reader(f)
		readCodes = list(reader)

#Determine if any codes match between readCodes and validCodes
	for foundCode in readCodes:
		if foundCode[0] in validCodes:
			print("Found a match for valid code: {}".format(foundCode[0]))
			matchedCodes.append(foundCode[0])
	print("Matched Codes:{}".format(matchedCodes))
#If matchedCodes is not empty, send error codes to DB
	if matchedCodes:
		sendErrCodes()
		matchedCodes.clear()	#Clear matchedCodes for later use


#Read valid codes into a list
def readValidCodes(codesFile):
	global validCodes
	with open( codesFile, newline='\n') as f:
		validCodes = f.read().splitlines()

#Read list of error codes to check and compare for
readValidCodes(validCodesFile)

#check Internet connection
checkInternetConn()

#if error codes are stored already within local cache, send them first
checkLocal()


try:
	while (1):
		s=datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
		s= "csvFiles/OBDII" + s +".csv"
		f=int(random.expovariate(1/30)+1)
		out=s+","+str(f)
		print(out)
		f1=open(s,'w+')
		for index in range(1,f):
			with open('OBDIICodes.csv', "r") as code_file:
				g=random.randint(1,total_codes);
				for i, line in enumerate(code_file):
					if i == g:
						f1.write(line)
		#close the file's stream to be able to read in scanCSV method
		f1.close()
		#Start new thread responsible for finding error code matches and sending data
		thread.start_new_thread(scanCSV,(s,))
		time.sleep(delay)
except KeyboardInterrupt:
	print("\nOBDII Simulation Stopped");





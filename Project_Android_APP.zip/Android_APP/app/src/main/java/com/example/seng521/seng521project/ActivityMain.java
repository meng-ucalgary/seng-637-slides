package com.example.seng521.seng521project;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ActivityMain extends AppCompatActivity {
    private static Storage localDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        localDB = Storage.getInstance(this.getBaseContext());
        setView();
    }

    public void setView(){
        //Get the listview that will display the trips
        ListView listview = (ListView) findViewById(R.id.list_view);

        //Set the title
        String title = "TRIPS";
        TextView textTitle = (TextView) findViewById(R.id.list_title);
        textTitle.setText(title);

        ArrayList<Trip> testTrips = localDB.getTrips();

        //Create the adapter that is responsible for displaying the content on the list
        CardListAdapter adapter = new CardListAdapter(getBaseContext(), testTrips);
        listview.setAdapter(adapter);
    }

    public void addFabOnClick(View addButton){
        final Intent intent  = new Intent(ActivityMain.this, ActivityTrip.class);
        startActivity(intent);
    }

    public class CardListAdapter extends BaseAdapter {

        //The data to be displayed
        private ArrayList<Trip> trips;

        //The activity that contains the list
        private Context context;

        //Constructor
        public CardListAdapter(Context context, ArrayList<Trip> List) {
            this.trips = List;
            this.context = context;
        }

        @Override
        public int getCount() {
            return trips.size();
        }

        @Override
        public Object getItem(int position) {
            return trips.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        //This function gets triggered whenever the user scrolls
        //the list to display the items on the screen
        public View getView(int position, View convertView, ViewGroup parent) {

            //Get the template
            View v = convertView;
            if (v == null) {
                LayoutInflater vi = LayoutInflater.from(context);
                v = vi.inflate(R.layout.list_card, null);
            }

            //Get the item to be displayed
            final Trip trip = (Trip) getItem(position);

            //Set onClickListener for touching a trip card
            //details will be shown in this popup window
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View popView) {
                    String response = queryRemoteDB(trip);

                    final Dialog popUp = new Dialog(ActivityMain.this);
                    popUp.setContentView(R.layout.view_trip_info);

                    ImageView imageView1 = (ImageView) popUp.findViewById(R.id.cylMis_status);
                    if(trip.isCylMis())
                        imageView1.setImageResource(R.drawable.ic_status_error);
                    else
                        imageView1.setImageResource(R.drawable.ic_status_noerror);

                    ImageView imageView2 = (ImageView) popUp.findViewById(R.id.fuelStat_status);
                    if(trip.isFuelStat())
                        imageView2.setImageResource(R.drawable.ic_status_error);
                    else
                        imageView2.setImageResource(R.drawable.ic_status_noerror);

                    ImageView imageView3 = (ImageView) popUp.findViewById(R.id.rpmLimit_status);
                    if(trip.isRpmLimit())
                        imageView3.setImageResource(R.drawable.ic_status_error);
                    else
                        imageView3.setImageResource(R.drawable.ic_status_noerror);

                    ImageView imageView4 = (ImageView) popUp.findViewById(R.id.seatBelt_status);
                    if(trip.isSeatBelt())
                        imageView4.setImageResource(R.drawable.ic_status_error);
                    else
                        imageView4.setImageResource(R.drawable.ic_status_noerror);

                    ImageView imageView5 = (ImageView) popUp.findViewById(R.id.brakePedal_status);
                    if(trip.isBrakePedal())
                        imageView5.setImageResource(R.drawable.ic_status_error);
                    else
                        imageView5.setImageResource(R.drawable.ic_status_noerror);

                    ImageView imageView6 = (ImageView) popUp.findViewById(R.id.abs_status);
                    if(trip.isAbs())
                        imageView6.setImageResource(R.drawable.ic_status_error);
                    else
                        imageView6.setImageResource(R.drawable.ic_status_noerror);

                    ImageView imageView7 = (ImageView) popUp.findViewById(R.id.powerSteerFail_status);
                    if(trip.isPowerSteerFail())
                        imageView7.setImageResource(R.drawable.ic_status_error);
                    else
                        imageView7.setImageResource(R.drawable.ic_status_noerror);

                    ImageView imageView8 = (ImageView) popUp.findViewById(R.id.heaterFail_status);
                    if(trip.isHeaterFail())
                        imageView8.setImageResource(R.drawable.ic_status_error);
                    else
                        imageView8.setImageResource(R.drawable.ic_status_noerror);

                    popUp.show();
                }
            });

            //Populate the card
            TextView textView1 = (TextView) v.findViewById(R.id.trip_name);
            textView1.setText(trip.getName());

            TextView textView2 = (TextView) v.findViewById(R.id.trip_date);
            textView2.setText(trip.getTimestampStart());

            TextView textView3 = (TextView) v.findViewById(R.id.trip_time);
            textView3.setText(trip.getTimestampEnd());

            return v;
        }
    }

    public String queryRemoteDB(Trip trip){
        String response = null;
        try{
            URL url = new URL("http://192.168.1.63/getTripData.php");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(15000);
            urlConnection.setConnectTimeout(15000);
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);

            OutputStream out = urlConnection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, "UTF-8"));
            writer.write("SELECT errorID FROM errorCodes WHERE dateTime > " + trip.getTimestampStart() + " AND dateTime < " + trip.getTimestampEnd() + ";");
            writer.flush();
            writer.close();
            out.close();

            int respoonseCode = urlConnection.getResponseCode();
            if(respoonseCode == HttpURLConnection.HTTP_OK){
                String line;
                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                while(((line = reader.readLine()) != null)){
                    response += line;
                }
            }
            else
                response = "";
        }catch (Exception e){
            e.printStackTrace();
        }

        return response;
    }

}
